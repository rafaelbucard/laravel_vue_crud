## Laravel & Vue CRUD Single Page Application (SPA) Tutorial
Using Laravel and Vue.js, we are going to create a single page application. We will learn who to create, read, update and delete using Vue.Js frontend and Laravel API backend.

## Tutorial Link
[Laravel & Vue CRUD Single Page Application (SPA) Tutorial](https://www.mynotepaper.com/laravel-vue-crud-single-page-application-tutorial.html)

## Output
![laravel-vue-crud-spa](https://user-images.githubusercontent.com/13184472/61147699-d002be80-a4fe-11e9-89cd-0fad422e4b89.gif)
## LICENCE
You can download the project, modify the code and use it anywhere you want without re-posting on any blog. Happy Coding :)

Thank you.
